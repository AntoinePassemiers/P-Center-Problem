import matplotlib.pyplot as plt
import numpy as np


# hard/instance9.dat
LB = [1, 1, 23, 36, 36, 37]
UB = [190, 64, 43, 43, 38, 38]
A = [64, 22, 29, 38, 36, 37]
B = [127, 43, 35, 40, 36, 37]
X = np.arange(1, 7)

plt.plot(X, UB, c="red", label="Upper bound")
plt.plot(X, B, c="orange", label="Value of b")
plt.plot(X, A, c="blue", label="Value of a")
plt.plot(X, LB, c="purple", label="Lower bound")
plt.legend()
plt.xlabel("Iterations of DB3")
plt.ylabel("Objective value")
plt.savefig("imgs/db3_bounds.png")
plt.clf()


# easy/instance10_1_1.dat
X = np.arange(1, 8)
MIN = [0, 54, 54, 64, 68, 74, 74]
MAX = [100, 100, 77, 77, 77, 77, 75]
LB = [np.nan, np.nan, 77, 77, 77, 77, 75]

plt.step(X, MAX, c="red", label="Maximum value for LB")
plt.step(X, MIN, c="purple", label="Minimum value for LB")
plt.legend()
plt.xlabel("Iterations of BINARY")
plt.ylabel("Objective value")
plt.savefig("imgs/binary_bounds.png")